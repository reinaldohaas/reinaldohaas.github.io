
function Div(el)
  for _, cls in ipairs({"ficha", "boletim"}) do
    if el.classes:includes(cls) then
      return {pandoc.RawBlock("latex", "\\begin{" .. cls .. "}")}
        .. el.content .. {pandoc.RawBlock("latex", "\\end{" .. cls .. "}")}
    end
  end
end

-- As árvores genealógicas são largas: cada uma vai numa página em paisagem.
function Figure(el)
  local arvore = false
  el:walk({Image = function(i) if i.src:match("arvore_%d+") then arvore = true end end})
  if not arvore then return nil end
  el = el:walk({Image = function(i)
    i.attributes.width = "100%"
    i.attributes.height = "88%"
    return i
  end})
  return {pandoc.RawBlock("latex", "\\begin{paisagem}"), el,
          pandoc.RawBlock("latex", "\\end{paisagem}")}
end
