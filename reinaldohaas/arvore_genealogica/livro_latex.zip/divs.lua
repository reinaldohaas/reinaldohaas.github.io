
function Div(el)
  for _, cls in ipairs({"ficha", "boletim"}) do
    if el.classes:includes(cls) then
      return {pandoc.RawBlock("latex", "\\begin{" .. cls .. "}")}
        .. el.content .. {pandoc.RawBlock("latex", "\\end{" .. cls .. "}")}
    end
  end
end
